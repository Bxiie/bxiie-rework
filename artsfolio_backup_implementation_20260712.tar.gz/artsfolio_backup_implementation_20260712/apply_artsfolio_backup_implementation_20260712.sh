#!/bin/bash
set -euo pipefail

readonly SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly ROOT="${ARTSFOLIO_ROOT:-/var/www/artsfolio}"
readonly BACKUP_DIR="$ROOT/.update-backups/offsite-backup-$(date +%Y%m%d%H%M%S)"

[[ -d "$ROOT/app" && -d "$ROOT/scripts" ]] || { echo "[FAIL] ArtsFolio root not found: $ROOT" >&2; exit 1; }
install -d -m 0750 "$BACKUP_DIR"

while IFS= read -r -d '' source; do
    relative="${source#"$SOURCE_DIR/overlay/"}"
    target="$ROOT/$relative"
    if [[ -e "$target" ]]; then
        install -d "$BACKUP_DIR/$(dirname "$relative")"
        cp -a "$target" "$BACKUP_DIR/$relative"
    fi
    install -d "$(dirname "$target")"
    cp -a "$source" "$target"
done < <(find "$SOURCE_DIR/overlay" -type f -print0)

chmod 0755 "$ROOT/scripts/backup/"*.sh

echo "[PASS] Backup implementation files installed."
echo "[INFO] Previous files saved under: $BACKUP_DIR"
echo "[NEXT] Follow: $ROOT/docs/dev/backup-restore-cookbook.md"
echo "[NEXT] Run: php -l app/Platform/Monitoring/OperationsMonitor.php"
echo "[NEXT] Run: php scripts/test/backup_operations_static.php"
echo "[NEXT] Run: ./scripts/test/preflight.sh"
# End of file.
