ArtsFolio encrypted off-site backup implementation bundle.

Local application:
  cd /Users/bxiie/Dropbox/tcdev/artsfolio
  bash /Users/bxiie/Downloads/artsfolio_backup_implementation_20260712/apply_artsfolio_backup_implementation_20260712.sh

Production application:
  sudo ARTSFOLIO_ROOT=/var/www/artsfolio bash apply_artsfolio_backup_implementation_20260712.sh

After applying, follow docs/dev/backup-restore-cookbook.md to create the B2 bucket,
install Restic, initialize the repository, install systemd units, and run the first
backup, weekly check, and monthly restore test.

# End of file.
