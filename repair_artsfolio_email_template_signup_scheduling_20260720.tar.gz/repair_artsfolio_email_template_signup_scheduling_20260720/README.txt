ArtsFolio email-template signup scheduling repair

Adds:
- Minutes-after-signup control for lifecycle templates.
- Recurring delivery control. After a successful send, the next copy is queued using the same interval.
- Safe template creation in approved email folders.
- Safe template rename within its existing folder and extension.
- Dynamic lifecycle template discovery for future tenant signups.
- Audit events for schedule, create, and rename actions.
- Static regression coverage and preflight integration.

Apply:
  cd /Users/bxiie/Downloads
  tar -xzf repair_artsfolio_email_template_signup_scheduling_20260720.tar.gz
  cd /Users/bxiie/Dropbox/tcdev/artsfolio
  ARTSFOLIO_ROOT=/Users/bxiie/Dropbox/tcdev/artsfolio \
  bash /Users/bxiie/Downloads/repair_artsfolio_email_template_signup_scheduling_20260720/apply_artsfolio_email_template_signup_scheduling_20260720.sh

Then run:
  ./scripts/test/preflight.sh

No database migration is required. Schedule metadata is stored in platform_settings.
