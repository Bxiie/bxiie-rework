#!/usr/bin/env bash
set -euo pipefail

ROOT="${ARTSFOLIO_ROOT:-$(pwd)}"
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
PATCH_FILE="$PACKAGE_DIR/changes.patch"
STAMP="$(date +%Y%m%d%H%M%S)"
BACKUP_DIR="$ROOT/.update-backups/email-template-signup-scheduling-$STAMP"

fail() { printf '[FAIL] %s\n' "$*" >&2; exit 1; }
pass() { printf '[PASS] %s\n' "$*"; }
write() { printf '[WRITE] %s\n' "$*"; }

[[ -f "$ROOT/app/Http/Controllers/Platform/Admin/EmailTemplatesController.php" ]] || fail "ARTSFOLIO_ROOT does not look like the ArtsFolio repository: $ROOT"
[[ -f "$PATCH_FILE" ]] || fail "Missing patch payload: $PATCH_FILE"
command -v patch >/dev/null 2>&1 || fail "The patch command is required."
command -v php >/dev/null 2>&1 || fail "PHP is required for validation."

cd "$ROOT"
if patch -p1 --dry-run --forward --silent < "$PATCH_FILE"; then
  mkdir -p "$BACKUP_DIR"
  while IFS= read -r file; do
    [[ -f "$file" ]] || continue
    mkdir -p "$BACKUP_DIR/$(dirname "$file")"
    cp -p "$file" "$BACKUP_DIR/$file"
  done < <(grep -E '^--- a/' "$PATCH_FILE" | sed 's#^--- a/##' | sed 's#[[:space:]].*$##')
  printf '[PASS] Backup created at %s\n' "${BACKUP_DIR#$ROOT/}"
  patch -p1 --forward < "$PATCH_FILE"
elif patch -p1 --reverse --dry-run --silent < "$PATCH_FILE"; then
  pass "Email-template signup scheduling patch is already applied."
else
  fail "Patch does not match this checkout. No files were changed. Upload a fresh ArtsFolio context archive for a rebased repair."
fi

for file in \
  app/Http/Controllers/Platform/Admin/EmailTemplatesController.php \
  app/Http/Routes/platform.php \
  app/Platform/Email/EmailTemplateCatalog.php \
  app/Platform/Email/RecurringLifecycleEmailScheduler.php \
  app/Platform/Signup/TenantSignupService.php \
  scripts/workers/email_run_once.php \
  scripts/test/email_template_signup_schedule_static.php; do
  php -l "$file"
done

php scripts/test/email_template_signup_schedule_static.php
php scripts/test/platform_email_templates_admin_static.php
php scripts/test/platform_email_template_status_static.php
php scripts/test/lifecycle_email_queue.php

write "Email-template editor now supports signup delay minutes, recurrence, creation, and rename."
pass "Repair applied and targeted checks passed."
printf '\nNext recommended command:\n  ./scripts/test/preflight.sh\n'
