ArtsFolio verification-link and AI-bundle repair

Fixes:
- {{verification_url}} remaining unresolved in verification email.
- scripts/bundle_artsfolio_for_ai.sh including artsfolio-video-factory.

Apply:

cd /Users/bxiie/Downloads
tar -xzf repair_artsfolio_verification_link_and_ai_bundle_exclusion_20260720.tar.gz
cd repair_artsfolio_verification_link_and_ai_bundle_exclusion_20260720

ARTSFOLIO_ROOT=/Users/bxiie/Dropbox/tcdev/artsfolio \
bash ./apply_artsfolio_verification_link_and_ai_bundle_exclusion_20260720.sh

Then:

cd /Users/bxiie/Dropbox/tcdev/artsfolio
./scripts/test/preflight.sh
