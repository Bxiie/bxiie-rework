#!/bin/bash
set -euo pipefail

ROOT="${ARTSFOLIO_ROOT:-${1:-$(pwd)}}"
MAILER="${ROOT}/app/Platform/Auth/SignupPostRegistrationMailer.php"
BUNDLER="${ROOT}/scripts/bundle_artsfolio_for_ai.sh"
STAMP="$(date +%Y%m%d%H%M%S)"
BACKUP="${ROOT}/.update-backups/verification-link-ai-bundle-${STAMP}"

for f in "${MAILER}" "${BUNDLER}"; do
  [ -f "${f}" ] || { echo "[FAIL] Missing ${f}" >&2; exit 1; }
done

mkdir -p "${BACKUP}/app/Platform/Auth" "${BACKUP}/scripts"
cp "${MAILER}" "${BACKUP}/app/Platform/Auth/SignupPostRegistrationMailer.php"
cp "${BUNDLER}" "${BACKUP}/scripts/bundle_artsfolio_for_ai.sh"

python3 - "${MAILER}" "${BUNDLER}" <<'PY'
from pathlib import Path
import re, sys

mailer_path = Path(sys.argv[1])
bundler_path = Path(sys.argv[2])

mailer = mailer_path.read_text(encoding="utf-8")
orig = mailer

needle = """            '{{ verification_url }}' => $url,
            '{{VERIFICATION_URL}}' => $url,
"""
replacement = """            '{{ verification_url }}' => $url,
            '{{verification_url}}' => $url,
            '{{VERIFICATION_URL}}' => $url,
"""

if "'{{verification_url}}' => $url" not in mailer:
    if needle not in mailer:
        raise SystemExit("[FAIL] Could not locate verification URL placeholder map.")
    mailer = mailer.replace(needle, replacement, 1)

email_needle = """            '{{ recipient_email }}' => $email,
            '{{RECIPIENT_EMAIL}}' => $email,
"""
email_replacement = """            '{{ recipient_email }}' => $email,
            '{{recipient_email}}' => $email,
            '{{RECIPIENT_EMAIL}}' => $email,
"""
if "'{{recipient_email}}' => $email" not in mailer and email_needle in mailer:
    mailer = mailer.replace(email_needle, email_replacement, 1)

if mailer != orig:
    mailer_path.write_text(mailer, encoding="utf-8")
    print(f"[WRITE] {mailer_path}")
else:
    print(f"[PASS] Verification placeholders already current: {mailer_path}")

bundler = bundler_path.read_text(encoding="utf-8")
orig_bundler = bundler

if "artsfolio-video-factory" not in bundler:
    lines = bundler.splitlines()
    inserted = False

    for i, line in enumerate(lines):
        if re.search(r'\btar\b', line):
            if line.rstrip().endswith("\\"):
                indent = re.match(r'\s*', line).group(0)
                lines.insert(i + 1, indent + "  --exclude='./artsfolio-video-factory' \\")
            else:
                lines[i] = line.replace(
                    "tar ",
                    "tar --exclude='./artsfolio-video-factory' ",
                    1,
                )
            inserted = True
            break

    if not inserted:
        for i, line in enumerate(lines):
            if re.search(r'\brsync\b', line):
                if line.rstrip().endswith("\\"):
                    indent = re.match(r'\s*', line).group(0)
                    lines.insert(i + 1, indent + "  --exclude='artsfolio-video-factory/' \\")
                else:
                    lines[i] = line.replace(
                        "rsync ",
                        "rsync --exclude='artsfolio-video-factory/' ",
                        1,
                    )
                inserted = True
                break

    if not inserted:
        raise SystemExit("[FAIL] Could not identify tar or rsync command in bundle_artsfolio_for_ai.sh.")

    bundler = "\n".join(lines) + ("\n" if orig_bundler.endswith("\n") else "")

if "artsfolio-video-factory" not in bundler:
    raise SystemExit("[FAIL] Exclusion was not added.")

if bundler != orig_bundler:
    bundler_path.write_text(bundler, encoding="utf-8")
    print(f"[WRITE] {bundler_path}")
else:
    print(f"[PASS] AI bundler already excludes artsfolio-video-factory: {bundler_path}")
PY

php -l "${MAILER}"
bash -n "${BUNDLER}"

echo "[PASS] Verification link and AI bundle exclusion repair applied."
echo "[BACKUP] ${BACKUP}"
echo "[NEXT] Run ./scripts/test/preflight.sh"
